create function hypertable_size(hypertable regclass) returns bigint
    strict
    SET search_path = pg_catalog
    language sql
as
$$
    -- One row per data node is returned (in case of a distributed
   -- hypertable), so sum them up:
   SELECT sum(total_bytes)::bigint
   FROM public.hypertable_detailed_size(hypertable);
$$;

alter function hypertable_size(regclass) owner to postgres;

