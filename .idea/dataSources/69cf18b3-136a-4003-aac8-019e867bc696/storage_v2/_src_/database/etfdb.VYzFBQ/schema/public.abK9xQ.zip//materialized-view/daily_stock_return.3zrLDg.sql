create materialized view daily_stock_return as
SELECT daily_bars.stock_id,
       daily_bars.day,
       daily_bars.open,
       daily_bars.close,
       round(- (1::numeric - daily_bars.close / daily_bars.open), 4) AS intraday_change_in_percent
FROM daily_bars;

alter materialized view daily_stock_return owner to postgres;

