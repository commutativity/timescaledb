create materialized view three_bar as
SELECT a.day,
       a.symbol,
       a.stock_id,
       a.close,
       a.volume,
       a.previous_close,
       a.previous_volume,
       a.previous_previous_close,
       a.previous_previous_volume,
       a.previous_previous_previous_close,
       a.previous_previous_previous_volume
FROM (SELECT daily_bars.day,
             s.symbol,
             daily_bars.stock_id,
             daily_bars.close,
             daily_bars.volume,
             lag(daily_bars.close, 1) OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day)  AS previous_close,
             lag(daily_bars.volume, 1)
             OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day)                           AS previous_volume,
             lag(daily_bars.close, 2)
             OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day)                           AS previous_previous_close,
             lag(daily_bars.volume, 2)
             OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day)                           AS previous_previous_volume,
             lag(daily_bars.close, 3)
             OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day)                           AS previous_previous_previous_close,
             lag(daily_bars.volume, 3)
             OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day)                           AS previous_previous_previous_volume
      FROM daily_bars
               JOIN stock s ON s.id = daily_bars.stock_id) a
WHERE a.close > a.previous_close
  AND a.previous_close > a.previous_previous_close
  AND a.previous_previous_close > a.previous_previous_previous_close
  AND a.volume > a.previous_volume
  AND a.previous_volume > a.previous_previous_volume
  AND a.previous_previous_volume > a.previous_previous_previous_volume
ORDER BY a.day DESC;

alter materialized view three_bar owner to postgres;

