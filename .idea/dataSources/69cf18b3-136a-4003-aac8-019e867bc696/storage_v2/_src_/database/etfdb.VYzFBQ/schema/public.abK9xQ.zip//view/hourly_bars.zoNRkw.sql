create view hourly_bars(stock_id, day, open, high, low, close, volume) as
SELECT _materialized_hypertable_4.stock_id,
       _materialized_hypertable_4.day,
       _timescaledb_internal.finalize_agg('public.first(pg_catalog.anyelement,pg_catalog."any")'::text, NULL::name,
                                          NULL::name, '{{pg_catalog,numeric},{pg_catalog,timestamp}}'::name[],
                                          _materialized_hypertable_4.agg_3_3, NULL::numeric) AS open,
       _timescaledb_internal.finalize_agg('pg_catalog.max(numeric)'::text, NULL::name, NULL::name,
                                          '{{pg_catalog,numeric}}'::name[], _materialized_hypertable_4.agg_4_4,
                                          NULL::numeric)                                     AS high,
       _timescaledb_internal.finalize_agg('pg_catalog.min(numeric)'::text, NULL::name, NULL::name,
                                          '{{pg_catalog,numeric}}'::name[], _materialized_hypertable_4.agg_5_5,
                                          NULL::numeric)                                     AS low,
       _timescaledb_internal.finalize_agg('public.last(pg_catalog.anyelement,pg_catalog."any")'::text, NULL::name,
                                          NULL::name, '{{pg_catalog,numeric},{pg_catalog,timestamp}}'::name[],
                                          _materialized_hypertable_4.agg_6_6, NULL::numeric) AS close,
       _timescaledb_internal.finalize_agg('pg_catalog.sum(numeric)'::text, NULL::name, NULL::name,
                                          '{{pg_catalog,numeric}}'::name[], _materialized_hypertable_4.agg_7_7,
                                          NULL::numeric)                                     AS volume
FROM _timescaledb_internal._materialized_hypertable_4
WHERE _materialized_hypertable_4.day <
      COALESCE(_timescaledb_internal.to_timestamp_without_timezone(_timescaledb_internal.cagg_watermark(4)),
               '-infinity'::timestamp without time zone)
GROUP BY _materialized_hypertable_4.stock_id, _materialized_hypertable_4.day
UNION ALL
SELECT stock_price.stock_id,
       time_bucket('01:00:00'::interval, stock_price.dt) AS day,
       first(stock_price.open, stock_price.dt)           AS open,
       max(stock_price.high)                             AS high,
       min(stock_price.low)                              AS low,
       last(stock_price.close, stock_price.dt)           AS close,
       sum(stock_price.volume)                           AS volume
FROM stock_price
WHERE stock_price.dt >=
      COALESCE(_timescaledb_internal.to_timestamp_without_timezone(_timescaledb_internal.cagg_watermark(4)),
               '-infinity'::timestamp without time zone)
GROUP BY stock_price.stock_id, (time_bucket('01:00:00'::interval, stock_price.dt));

alter table hourly_bars
    owner to postgres;

