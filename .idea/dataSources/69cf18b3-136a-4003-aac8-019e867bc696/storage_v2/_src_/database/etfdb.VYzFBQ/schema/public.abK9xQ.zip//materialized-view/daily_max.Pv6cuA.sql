create materialized view daily_max as
WITH prev_day_closing AS (
    SELECT daily_bars.stock_id,
           daily_bars.day,
           daily_bars.close,
           lead(daily_bars.close)
           OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day DESC) AS prev_day_closing_price
    FROM daily_bars
),
     daily_factor AS (
         SELECT prev_day_closing.stock_id,
                prev_day_closing.day,
                prev_day_closing.close,
                prev_day_closing.prev_day_closing_price,
                prev_day_closing.close / prev_day_closing.prev_day_closing_price AS daily_factor
         FROM prev_day_closing
     )
SELECT daily_factor.day,
       last(s.symbol, daily_factor.daily_factor)              AS symbol,
       last(daily_factor.stock_id, daily_factor.daily_factor) AS stock_id,
       round(daily_factor.daily_factor, 4)                    AS max_daily_factor
FROM daily_factor
         JOIN stock s ON s.id = daily_factor.stock_id
GROUP BY daily_factor.day, daily_factor.daily_factor
ORDER BY daily_factor.day DESC, daily_factor.daily_factor DESC;

alter materialized view daily_max owner to postgres;

