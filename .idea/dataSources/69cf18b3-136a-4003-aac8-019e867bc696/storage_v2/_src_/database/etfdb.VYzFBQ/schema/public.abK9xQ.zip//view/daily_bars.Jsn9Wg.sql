create view daily_bars(stock_id, day, open, high, low, close, volume) as
SELECT _materialized_hypertable_9.stock_id,
       _materialized_hypertable_9.day,
       round(_timescaledb_internal.finalize_agg('public.first(pg_catalog.anyelement,pg_catalog."any")'::text,
                                                NULL::name, NULL::name,
                                                '{{pg_catalog,float8},{pg_catalog,timestamp}}'::name[],
                                                _materialized_hypertable_9.agg_3_3, NULL::double precision)::numeric,
             2)                                                                      AS open,
       round(_timescaledb_internal.finalize_agg('pg_catalog.max(double precision)'::text, NULL::name, NULL::name,
                                                '{{pg_catalog,float8}}'::name[], _materialized_hypertable_9.agg_4_4,
                                                NULL::double precision)::numeric, 2) AS high,
       round(_timescaledb_internal.finalize_agg('pg_catalog.min(double precision)'::text, NULL::name, NULL::name,
                                                '{{pg_catalog,float8}}'::name[], _materialized_hypertable_9.agg_5_5,
                                                NULL::double precision)::numeric, 2) AS low,
       round(_timescaledb_internal.finalize_agg('public.last(pg_catalog.anyelement,pg_catalog."any")'::text, NULL::name,
                                                NULL::name, '{{pg_catalog,float8},{pg_catalog,timestamp}}'::name[],
                                                _materialized_hypertable_9.agg_6_6, NULL::double precision)::numeric,
             2)                                                                      AS close,
       _timescaledb_internal.finalize_agg('pg_catalog.sum(numeric)'::text, NULL::name, NULL::name,
                                          '{{pg_catalog,numeric}}'::name[], _materialized_hypertable_9.agg_7_7,
                                          NULL::numeric)                             AS volume
FROM _timescaledb_internal._materialized_hypertable_9
WHERE _materialized_hypertable_9.day <
      COALESCE(_timescaledb_internal.to_timestamp_without_timezone(_timescaledb_internal.cagg_watermark(9)),
               '-infinity'::timestamp without time zone)
GROUP BY _materialized_hypertable_9.stock_id, _materialized_hypertable_9.day
UNION ALL
SELECT stock_price_im.stock_id,
       time_bucket('1 day'::interval, stock_price_im.dt_im)                AS day,
       round(first(stock_price_im.open, stock_price_im.dt_im)::numeric, 2) AS open,
       round(max(stock_price_im.high)::numeric, 2)                         AS high,
       round(min(stock_price_im.low)::numeric, 2)                          AS low,
       round(last(stock_price_im.close, stock_price_im.dt_im)::numeric, 2) AS close,
       sum(stock_price_im.volume)                                          AS volume
FROM stock_price_im
WHERE stock_price_im.dt_im >=
      COALESCE(_timescaledb_internal.to_timestamp_without_timezone(_timescaledb_internal.cagg_watermark(9)),
               '-infinity'::timestamp without time zone)
GROUP BY stock_price_im.stock_id, (time_bucket('1 day'::interval, stock_price_im.dt_im));

alter table daily_bars
    owner to postgres;

