create materialized view sma_14 as
SELECT stock.symbol,
       daily_bars.day,
       daily_bars.close,
       round(avg(daily_bars.close)
             OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day ROWS BETWEEN 13 PRECEDING AND CURRENT ROW),
             2) AS sma_14
FROM daily_bars
         JOIN stock ON daily_bars.stock_id = stock.id
ORDER BY daily_bars.stock_id, daily_bars.day;

alter materialized view sma_14 owner to postgres;

