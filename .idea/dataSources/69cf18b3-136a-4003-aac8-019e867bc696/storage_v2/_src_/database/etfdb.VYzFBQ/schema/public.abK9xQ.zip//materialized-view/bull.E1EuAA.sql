create materialized view bull as
SELECT a.day,
       a.symbol,
       a.stock_id,
       a.open,
       a.close,
       a.previous_open,
       a.previous_close
FROM (SELECT daily_bars.day,
             s.symbol,
             daily_bars.stock_id,
             daily_bars.open,
             daily_bars.close,
             lag(daily_bars.open, 1) OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day)  AS previous_open,
             lag(daily_bars.close, 1) OVER (PARTITION BY daily_bars.stock_id ORDER BY daily_bars.day) AS previous_close
      FROM daily_bars
               JOIN stock s ON daily_bars.stock_id = s.id) a
WHERE a.previous_close < a.previous_open
  AND a.previous_open < a.close
  AND a.previous_close > a.open
ORDER BY a.day DESC;

alter materialized view bull owner to postgres;

